<?php

require('model/Mikrotik.php');

$userid = isset($_SESSION['UserId']) ? $_SESSION['UserId'] : NULL;
if ($_SESSION['UserType']=='RE'){
    $mik_id= $userid;
    $mikrotikLoginData = $obj->details_by_cond('mikrotik_user', 'user_id ='.$mik_id);
}else{
    if (isset($_GET['mik_id'])){
        $mik_id = $_GET['mik_id'];
    }else{
        $mik_id = 1;
    }
    $mikrotikLoginData = $obj->details_by_cond('mikrotik_user', 'id ='.$mik_id);
}

$mikrotiks = $obj->view_all_by_cond('mikrotik_user','user_id=0');

$mikrotik = new Mikrotik($mikrotikLoginData['mik_ip'], $mikrotikLoginData['mik_username'], $mikrotikLoginData['mik_password']);


date_default_timezone_set('Asia/Dhaka');
$date_time = date('Y-m-d g:i:sA');
$date = date('Y-m-d');
$ip_add = $_SERVER['REMOTE_ADDR'];
$userid = isset($_SESSION['UserId']) ? $_SESSION['UserId'] : NULL;

if ($ty=='RE'){
    $agent_by_user = $obj->view_all_by_cond('tbl_agent','entry_by='.$userid);
}

$notification = "";
//taking month and years
$day = date('M-Y');

if ($mikrotik->checkConnection()) {
    $allSecretData = $mikrotik->viewAllPppSecret();
    $allRunnigSecretData = $mikrotik->interfaceStatus();


    foreach($allSecretData as $seData){
        foreach($allRunnigSecretData as $rseData){
            $rseData['name'] = trim(str_replace('<pppoe-','',$rseData['name']),'>');
            if($seData['name']==$rseData['name']){
                continue;

            }
            //echo $seData['name'];
        }
    }

    if ($_SESSION['UserType']!='RE'){
        ?>
        <div class="panel panel-default">
            <div class="box-tools pull-right col-md-3">
                <div class="btn-group">
                    <button type="button" class="btn btn-info">Select Mikrotik</button>
                    <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <ul class="dropdown-menu" role="menu">
                        <?php foreach ($mikrotiks as $mikrotik){?>
                            <li><a href="?q=mikrotik_all_running_secret&mik_id=<?= $mikrotik['id']?>"><?= $mikrotik['mik_username']?> - <?= $mikrotik['mik_ip']?></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
    <?php } ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2 margin_15_px">
            <div class="alert alert-success text-center">
                <strong>Welcome To Mikrotik</strong>
                <br>
                <small>Successfully connected to Mikrotik Router by IP
                    :<?php echo $mikrotikLoginData['mik_ip']; ?></small>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 mikrotikTable table-responsive">
            <div class="panel panel-default">
                <h4 class="text-center">All Microtik Running Secret Information of <?= $mikrotikLoginData['mik_ip'] ?></h4>
            </div>
            <table class="table table-responsive table-bordered table-hover table-striped" id="example">
                <thead>
                <tr>
                    <th class="text-center">SL</th>
                    <th class="text-center">Name</th>
                    <th class="text-center">Rx Byte</th>
                    <th class="text-center">Tx Byte</th>
                    <th class="text-center">Rx Packet</th>
                    <th class="text-center">Tx Packet</th>
                    <th class="text-center">Status</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $serial = 1;

                foreach ($allRunnigSecretData as $secretData) {
                    $secretData['name'] = trim(str_replace('<pppoe-','',$secretData['name']),'>');
                    if ($ty=='RE'){
                        foreach ($agent_by_user as $agent){
                            if ($agent['ip']==$secretData['name']){ ?>
                                <tr>
                                    <td><?php echo $serial; ?></td>
                                    <td><?php echo $secretData['name'] ?></td>
                                    <td><?php echo $secretData['rx-byte'] ?></td>
                                    <td><?php echo $secretData['tx-byte'] ?></td>
                                    <td><?php echo $secretData['rx-packet'] ?></td>
                                    <td><?php echo $secretData['tx-packet'] ?></td>
                                    <td>
                                        <?php
                                        if ($secretData['running'] == 'false') {
                                            echo '<button data-status="1" data-name="'.$secretData['name'].'" class="btn btn-xs btn-danger">Not Running</button>';
                                        } else {
                                            echo'<button data-status="0" data-name="'.$secretData['name'].'" class="btn btn-xs btn-success">Running</button>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                    }else{?>
                        <tr>
                            <td><?php echo $serial; ?></td>
                            <td><?php echo $secretData['name'] ?></td>
                            <td><?php echo $secretData['rx-byte'] ?></td>
                            <td><?php echo $secretData['tx-byte'] ?></td>
                            <td><?php echo $secretData['rx-packet'] ?></td>
                            <td><?php echo $secretData['tx-packet'] ?></td>
                            <td>
                                <?php
                                if ($secretData['running'] == 'false') {
                                    echo '<button data-status="1" data-name="'.$secretData['name'].'" class="btn btn-xs btn-danger">Not Running</button>';
                                } else {
                                    echo'<button  data-status="0" data-name="'.$secretData['name'].'" class="btn btn-xs btn-success">Running</button>';
                                }
                                ?>
                            </td>
                        </tr>
                    <?php } ?>

                    <?php $serial++;  } ?>
                </tbody>
            </table>
        </div>
    </div>
    <script type="text/javascript" src="asset/js/Chart.js"></script>
    <script type="text/javascript" src="mikrotik/mikrotik_assets/js/custom_chart_mikrotik.js"></script>
    <script>
        $(document).ready(function () {
            $('#example').DataTable();

            $('#example').on('click', 'tbody tr td button#secretCangeStatus', function (e) {
                e.preventDefault();
                var secretName = $(this).data('name');
                var status = $(this).html();
                $.ajax({
                    type: 'get',
                    url: 'mikrotik/enableDisableSecret.php',
                    data: {name: secretName, state: status},
                    success: function (result) {

                    }
                });
                if (status == 'Enable') {
                    $(this).html('Disable');
                    $(this).removeClass('btn-success');
                    $(this).addClass('btn-danger');
                } else {
                    $(this).html('Enable');
                    $(this).removeClass('btn-danger');
                    $(this).addClass('btn-success');
                }
            });
        });
    </script>
    <?php

} else {?>
    <div class="row"><div class="col-md-8 col-md-offset-2 margin_15_px"><div class="alert alert-danger text-center"><strong>Sorry, We cant connect to Mikrotik <?php echo $mikrotikLoginData['mik_ip'];?></strong><br><small>Please check your connection IP, Login Name and Password.</small></div></div></div>
    <div class="box-tools pull-right col-md-3">
        <div class="btn-group">
            <button type="button" class="btn btn-info">Select Another Mikrotik</button>
            <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                <span class="caret"></span>
                <span class="sr-only">Toggle Dropdown</span>
            </button>
            <ul class="dropdown-menu" role="menu">
                <?php foreach ($mikrotiks as $mikrotik){?>
                    <li><a href="?q=mikrotik_all_running_secret&mik_id=<?= $mikrotik['id']?>"><?= $mikrotik['mik_username']?> - <?= $mikrotik['mik_ip']?></a></li>
                <?php } ?>
            </ul>
        </div>
    </div>
<?php } ?>