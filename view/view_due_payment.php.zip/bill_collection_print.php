<?php
date_default_timezone_set('Asia/Dhaka');
$date_time = date('Y-m-d g:i:sA');
$date = date('Y-m-d');
$ip_add = $_SERVER['REMOTE_ADDR'];
$userid = isset($_SESSION['UserId']) ? $_SESSION['UserId'] : NULL;
$notification = "";
//taking month and years
$day = date('M-Y');

//Ends dues calculations
//check_bill_create_or_not
$cnt = $obj->Total_Count("monthly_bill_making_check", "month_year='$day'");
if ($cnt != 1) {
    // pull all the customer in bill collection 
    //weather the have no dues or paid
    //in next step we erase those customer who have no dues.
    $form_data = array(
        'pay_status' => 1, //Customer didn't pay yet   
        'due_status' => 0 //no dues
    );
    $obj->Update_data("tbl_agent", $form_data, "pay_status!=5");

    $form_data2 = array(
        'month_year' => $day //Insert current month date for future check weather bill is created or notification                                      
    );
    $obj->Insert_data("monthly_bill_making_check", $form_data2);
}


// ========== Now remove the customer from bill collection =================
// ========== Who paid already or no dues =================
foreach ($obj->view_all_by_cond("tbl_agent", "ag_status='1'") as $detailsid) {
    extract($detailsid);
    $id = $detailsid['ag_id'];
    $dues = $bill->get_customer_dues($id);
    //customer remove from bill collection list who have advanced paid or no dues
    if ($dues <= 0) {
        $form_data = array(
            'pay_status' => 0, //Customer paid  
            'due_status' => 0 //no dues                                 
        );
        $obj->Update_data("tbl_agent", $form_data, "where ag_id='$id'");
    }
    // this condition for if delete any given entry then comes bill list
    if ($dues > 0) {
        $form_data = array(
            'pay_status' => 1, //Customer paid                              
        );
        $obj->Update_data("tbl_agent", $form_data, "where ag_id='$id'");
    }
}


// ========== Full Due Function Start =================
//This function move the client from bill collection list to dues list
if( $obj->userWorkPermission($acc,'delete')){
    $dltoken = isset($_GET['dltoken']) ? $_GET['dltoken'] : NULL;
    if (!empty($dltoken)) {
        $form_data = array(
            'due_status' => 1
        );
        if ($obj->Update_data("tbl_agent", $form_data, "where ag_id='$dltoken'")) {
            $details3 = $obj->details_by_cond("tbl_agent", "ag_id='$dltoken'");
            extract($details3);
            $notification = 'Full Due Successfully of , ' . $details3['ag_name'] . ", ID: " . $details3['cus_id'];
        } else {
            $notification = 'Full Due Failed';
        }
    }
}

// ========== Full Due Function End =================

if (isset($_GET['zonePrint'])) {
    $zoneName = $obj->view_all("tbl_zone ORDER BY zone_name ASC");
    $printClientData = $obj->view_all_by_cond("vw_agent", "ag_status='1' and pay_status='1' AND due_status='0' AND zone = " . $_GET['zonePrint'] . " ORDER BY `vw_agent`.`ip` ASC");

}
elseif(isset($_GET['bid']))
{
  $zoneName = $obj->view_all("tbl_zone ORDER BY zone_name ASC");
    $printClientData = $obj->view_all_by_cond("vw_agent", "ag_status='1' and pay_status='1' AND due_status='0' AND billing_person_id = " . $_GET['bid'] . " ORDER BY `vw_agent`.`ip` ASC");
}
 else {

    /*$printClientData = $obj->view_all_by_cond("tbl_agent", "ag_status='1' and pay_status='1' AND due_status='0'  ORDER BY `tbl_agent`.`zone` ASC");*/
    $zoneName = $obj->view_all("tbl_zone ORDER BY zone_name ASC");
    $printClientData = $obj->view_all_by_cond("vw_agent", "ag_status='1' and pay_status='1' AND due_status='0'  ORDER BY ip ASC");
}
?>
<style type="text/css">
    .no-border-right {
  border-right: solid 1px #FFF!important;
  color: red;
}
</style>

<div class="col-md-12"
     style=" margin-top:5px; margin-bottom: 5px; font-size:14px;  color:red; font-weight:bold; text-align: center;">
    <h3><?php echo isset($notification) ? $notification : NULL; ?></h3>
</div>
<div class="col-md-1 col-md-offset-11">
    <button type="submit" class="btn btn-primary pull-right" onclick="printDiv('month_print')">Print Statement</button>
</div>
<div class="row" id="month_print">
    <div class="col-md-12"
         style=" background:#606060; margin-top:20px; margin-bottom: 15px; min-height:45px; padding:8px 0px 0px 15px; font-size:16px; font-family:Lucida Sans Unicode; color:#FFFFFF; font-weight:bold;">
         <div class="col-md-6">
             <b>View Customer Billing Information Of
            <?php
            if(isset($_GET['zonePrint'])){
            ?>
           <?php
          if (isset($_GET['zonePrint'])){
            $zone_id=$_GET['zonePrint'];
            $zone_value = $obj->details_by_cond("tbl_zone", "zone_id='$zone_id' ORDER BY zone_id DESC");

            echo $zone_value['zone_name'];
            }
        }
        elseif(isset($_GET['bid']))
          {
            $id=$_GET['bid'];
            $name = $obj->details_by_cond("_createuser", "UserId='$id'");

            echo $name['FullName'];
          }
            
        ?></b>
        </div>

    </div>
    <?php
if (isset($_GET['zonePrint'])) {
    ?>
    <div class="row" style="font-size: 12px;">
        <div class="col-md-12 table-responsive">
            <table class="table table-responsive table-bordered table-hover table-striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Customer Name</th>
                    <th style="text-align:center">IP</th>
                    <th>Address</th>
                    <th>Zone</th>
                    <th>Mobile No</th>
                    <th>Pre Dues</th>
                    <th>Bill</th>
                    <th>Total Bill</th>
                    <th>Remarks</th>
                  
                </tr>
                </thead>
                <tbody>
                <?php
                $i = '0';
                $total_due_amount = 0;
                $total_prevdue_bill=0;
                $toatl_running_bill=0;         
                foreach ($printClientData as $value) {

                        $GLOBALS['temp'] = $value['zone_name'];
                        $i++;
                    
                        $dueBill = $bill->get_customer_dues(isset($value['ag_id']) ? $value['ag_id'] : NULL); 
                    
                        $runningBill =isset($value['taka']) ? $value['taka'] : NULL; 
                    
                        $previousDue = $dueBill - $runningBill;

                if( $previousDue < 0) { $previousDue = 0; }
                    
        ?>
                      
                    <tr>
                        
                         <td style="width:50px;text-align:center;height:10px;padding:0px;margin:0px;text-size:8px"><?php echo isset($value['cus_id']) ? $value['cus_id'] : NULL; ?></td>
                        <td style="width:80px;height:18px;padding:0px 0px 0px 5px;;margin:0px;text-size:8px"><?php echo substr($value['ag_name'], 0, 20); ?></td>
                         
                         <td style="width:80px;height:10px;text-align:center; padding:0px;margin:0px;text-size:8px">
                            <?php echo substr($value['ip'], 0, 15); ?>
                        </td>

                        <td style="width:80px;height:10px;padding:0px 0px 0px 5px;margin:0px;text-size:8px"><?php echo substr($value['ag_office_address'], 0, 18) ?></td>
                        <td style="width:80px;height:10px;padding:0px 0px 0px 5px;margin:0px;text-size:8px"><?php echo substr($value['zone_name'], 0, 18) ?></td>
                      
                        <td style="width:100px;text-align:center;height:10px;padding:0px 0px 0px 5px;margin:0px;text-size:8px"><?php echo isset($value['ag_mobile_no']) ? $value['ag_mobile_no'] : NULL; ?></td>
                        
            <td style="width:30px;height:10px;text-align:center;padding:0px;margin:0px;text-size:8px">
                <?php echo number_format($previousDue); ?>
                        </td>
                        <td style="width:40px;height:10px;text-align:center;padding:0px;margin:0px;text-size:8px">
                            <?php echo number_format($runningBill); ?>
                         </td>
                         <td style="width:40px;height:10px;text-align:center;padding:0px;margin:0px;text-size:8px">
                            <?php echo number_format($dueBill);  ?>
                         </td>

                        <td style="width:200px;height:10px;text-align:center;padding:0px;margin:0px;text-size:8px"></td>

                    </tr>
                    <?php
                    $total_due_amount += $dueBill;
                    $total_prevdue_bill+=$previousDue;
                    $toatl_running_bill+=$runningBill;
                }
                ?>
                <tbody>
                <thead>
                        <tr>
                            <th colspan="6">
                                <div class="pull-right">Total Bill For  <?php echo $temp ?> :</div>
                            </th>
                            <th style="text-align: center;" colspan="3">
                                 <?php echo number_format($total_prevdue_bill); ?> + <?php echo number_format($toatl_running_bill); ?> = <?php echo number_format($total_due_amount);
                                ?>
                            </th>
                        </tr>
                        </tr>
                 </thead>
                 <thead>
                     <tr>
                       <th colspan="10" style="text-align: center;"><span style="color: green;">Total Amount In Word ::&nbsp;&nbsp;<span
                                        style="color: red;"><?PHP echo ucwords($formater->convert_number_to_words($total_due_amount)); ?>&nbsp;taka</span></span>
                        </th>
                    </tr>
                </thead>
            </table>
            <!-- <h4 class="text-teal-800" style="text-align: center">Total Bill: <?php echo number_format($total_due_amount); ?></h4> -->
        </div>
    </div>
<?php
}
else
{
?>
    <div class="row" style="font-size: 12px;">
        <div class="col-md-12 table-responsive">
            <table class="table table-responsive table-bordered table-hover table-striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Customer Name</th>
                    <th style="text-align:center">IP</th>
                    <th>Address</th>
                    <th>Zone</th>
                    <th>Mobile No</th>
                    <th>Pre Dues</th>
                    <th>Bill</th>
                    <th>Total Bill</th>
                    <th>Remarks</th>
                  
                </tr>
                </thead>
                <tbody>
                <?php
                $i = '0';
                $total_due_amount = 0;
                $totalBill = 0;
                $total_prevdue_bill=0;
                $toatl_running_bill=0;
                foreach ($zoneName as $zone) {          
                foreach ($printClientData as $value) {

                    if($zone['zone_name'] == $value['zone_name'])
                    {
                        $GLOBALS['temp'] = $value['zone_name'];
                        $i++;
                    
                        $dueBill = $bill->get_customer_dues(isset($value['ag_id']) ? $value['ag_id'] : NULL); 
                    
                        $runningBill =isset($value['taka']) ? $value['taka'] : NULL; 
                    
                        $previousDue = $dueBill - $runningBill;

                if( $previousDue < 0) { $previousDue = 0; }
                    
        ?>
                      
                    <tr>
                        
                         <td style="width:50px;text-align:center;height:10px;padding:0px;margin:0px;text-size:8px"><?php echo isset($value['cus_id']) ? $value['cus_id'] : NULL; ?></td>
                        <td style="width:80px;height:18px;padding:0px 0px 0px 5px;;margin:0px;text-size:8px"><?php echo substr($value['ag_name'], 0, 20); ?></td>
                         
                         <td style="width:80px;height:10px;text-align:center; padding:0px;margin:0px;text-size:8px">
                            <?php echo substr($value['ip'], 0, 15); ?>
                        </td>

                        <td style="width:80px;height:10px;padding:0px 0px 0px 5px;margin:0px;text-size:8px"><?php echo substr($value['ag_office_address'], 0, 18) ?></td>
                        <td style="width:80px;height:10px;padding:0px 0px 0px 5px;margin:0px;text-size:8px"><?php echo substr($value['zone_name'], 0, 18) ?></td>
                      
                        <td style="width:100px;text-align:center;height:10px;padding:0px 0px 0px 5px;margin:0px;text-size:8px"><?php echo isset($value['ag_mobile_no']) ? $value['ag_mobile_no'] : NULL; ?></td>
                        
            <td style="width:30px;height:10px;text-align:center;padding:0px;margin:0px;text-size:8px">
                <?php echo number_format($previousDue); ?>
                        </td>
                        <td style="width:40px;height:10px;text-align:center;padding:0px;margin:0px;text-size:8px">
                            <?php echo number_format($runningBill); ?>
                         </td>
                         <td style="width:40px;height:10px;text-align:center;padding:0px;margin:0px;text-size:8px">
                            <?php echo number_format($dueBill);  ?>
                         </td>

                        <td style="width:200px;height:10px;text-align:center;padding:0px;margin:0px;text-size:8px"></td>

                    </tr>
                    <?php
                    $total_due_amount += $dueBill;
                    $total_prevdue_bill+=$previousDue;
                    $toatl_running_bill+=$runningBill;
                    $totalBill += $dueBill;
                    } 
                }
                if($total_due_amount != 0)
                {
                ?>
                <tbody>
                    <thead>
                        <tr>
                            <th colspan="6">
                                <div class="pull-right">Total Bill For  <?php echo $temp ?> :</div>
                            </th>
                            <th style="text-align: center;" colspan="3">
                                 <?php echo number_format($total_prevdue_bill) ?> + <?php echo number_format($toatl_running_bill) ?> = <?php echo number_format($total_due_amount);
                                  $total_due_amount=0;
                                  $total_prevdue_bill=0; 
                                  $toatl_running_bill=0;
                                ?>
                            </th>
                        </tr>
                        </tr>
                    </thead>
                <!-- <td class="no-border-right" colspan="10"><h4 class="text-teal-800" style="text-align: center">Total Bill <?php echo $totalBill ?></h4></td> -->
                <?php
                }
            }
                ?>
                <!-- </tbody> -->
                <thead>
                     <tr>
                       <th colspan="10" style="text-align: center;"><span style="color: green;">Total Amount: <?php echo number_format($totalBill); ?>:&nbsp;&nbsp; In Word ::&nbsp;&nbsp;<span
                                        style="color: red;"><?PHP echo ucwords($formater->convert_number_to_words($totalBill)); ?>&nbsp;taka</span></span>
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    <?php
}
?>
</div>
<style>
    .dataTables_wrapper {
        top: 10px;
        left: -15px;
        width: 103%;

    }

    .d {
        width: 15%;
    }

    .d a {

    }

    #example_filter {
        position: absolute;
        right: 25px;
    }
</style>
<script>
    function printDiv(divName) {
        $(".print").css("margin-left", "0px");
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }
</script>